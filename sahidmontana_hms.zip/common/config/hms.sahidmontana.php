<?php
//=========change this scope=========================================================
$root = '/var/www/sahidmontana_hms/';
$db = 'hms_sahidmontana';
$db2 = 'landa_acc_sahidmontana';
$dbUser = 'root';
$dbPwd = 'landak';
$client = 'hms.sahidmontana';
$clientName = 'Sahid Montana';
//===================================================================================
?>
