<?php
//=========change this scope=========================================================
$root = '/var/www/sahidmontana_hms/';
$db = 'landa_acc_sahidmontana';
$db2 = 'landa_hms_sahidmontana';
$dbUser = 'root';
$dbPwd = 'landak';
$client = 'acc.sahidmontana';
$clientName = 'Sahid Montana';
//===================================================================================
?>
